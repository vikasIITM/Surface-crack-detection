# surface-crack-detection
## surfacecrackdetection.m
Input : Image matrix
Output : Image matrix
## How to Run
![alt-text](https://github.com/rjn32s/surface-crack-detection/blob/main/Open%20GUI.m%20file.gif)
## Algorithm

![alt-text](https://github.com/rjn32s/surface-crack-detection/blob/main/Algorithm_layout.png)
